﻿using E_Commerce.Models;
using Microsoft.AspNetCore.Mvc;

namespace E_Commerce.Controllers
{
    public class OrderController : Controller
    {

        private static List<Order> Orders = new List<Order>();
        private static int nextOrderId = 1;

        [HttpGet]
        public IActionResult Create()
        {
            return View();
        }

        [HttpPost]
        public IActionResult Create(Order order) 
        {
            if (!ModelState.IsValid) 
            {
                return View(order);
            }

            order.Id = nextOrderId++;
            Orders.Add(order);

            return RedirectToAction("Confirmation", new { id = order.Id });
        }

        public IActionResult Confirmation(int id) 
        {
            var order = Orders.FirstOrDefault(o => o.Id == id);
            if (order == null)
            {
                return NotFound();
            }

            return View(order);
        }
    }
}
