﻿using E_Commerce.Models;
using Microsoft.AspNetCore.Mvc;
using System.Diagnostics;

namespace E_Commerce.Controllers
{
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;

        public HomeController(ILogger<HomeController> logger)
        {
            _logger = logger;
        }

        public IActionResult Index()
        {
            return View(Products);
        }

        public IActionResult Details(int id) {
            var product = Products.FirstOrDefault(p => p.Id == id);
            if (product == null) 
            {
                return NotFound();
            }
            return View(product);
        }

        public IActionResult Privacy()
        {
            return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }

        public static List<Product> Products = new List<Product> {
            new Product { Id = 1, Name = "Product 1", Description = "This is Product 1", Price = 9.99M },
            new Product { Id = 2, Name = "Product 2", Description = "This is Product 2", Price = 10.99M },
        };

    }
}