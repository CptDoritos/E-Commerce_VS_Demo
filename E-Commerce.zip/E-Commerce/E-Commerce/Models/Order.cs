﻿namespace E_Commerce.Models
{
    public class Order
    {

        public int Id { get; set; }
        public int ProductId { get; set; }
        public String CustomerName { get; set; }
        public String ShippingAddress { get; set; }

    }
}
