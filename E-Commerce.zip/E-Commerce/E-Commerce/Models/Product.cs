﻿namespace E_Commerce.Models
{
    public class Product
    {

        public int Id { get; set; }
        public string Name { get; set; }
        public String Description { get; set; }
        public Decimal Price { get; set; }

    }
}
